/*
 * Created on Sat Nov 11 2023
 *
 * Copyright (c) 2023 Nadine von Frankenberg
 */

 /** Question interface
  * Each question is evaluated by a score
  * Questions are displayed in a view
  * The result can be shown & cleared
  */ 
  // No need to change this file!
 interface Question {
    int score(String answer);
    void display(TriviaView view);
    void showResult(String answer, TriviaView view);
    void clearResultText(TriviaView view);
}
